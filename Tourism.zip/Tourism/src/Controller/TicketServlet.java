package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.Ticket;
import Dao.TicketDao;

@WebServlet("/TicketServlet")
public class TicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public TicketServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		
		Ticket tec = new Ticket();
		
		tec.setFrom(from);
		tec.setTo(to);
		
		TicketDao ticketDao = new TicketDao();
		
		String ticketBooked = ticketDao.bookTicket(tec);
		
		if(ticketBooked.equals("SUCCESS")) {
			out.println("Your ticket(s) booked!!");
		}
		else {
			request.setAttribute("errMessage", ticketBooked);
			request.getRequestDispatcher("/Welcome.jsp").forward(request, response);
		}
	}

}
