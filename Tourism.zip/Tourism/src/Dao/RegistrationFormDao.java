package Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Bean.RegistrationFormBean;
import Util.RegisterDBConnection;

public class RegistrationFormDao {
	public String registerUser(RegistrationFormBean registerBean)
	 {
		 String fullName = registerBean.getFullName();
		 double phone = registerBean.getPhone();
		 String email = registerBean.getEmail();
		 String userName = registerBean.getUserName();
		 String password = registerBean.getPassword();
		 
		 Connection con = null;
		 PreparedStatement preparedStatement = null;		 
		 try
		 {
			 con = RegisterDBConnection.createConnection();
			 String query = "insert into RegistrationTable(fullName,phone,Email,userName,password) values (?,?,?,?,?)"; //Insert user details into the table 'USERS'
			 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
			
			 preparedStatement.setString(1, fullName);
			 preparedStatement.setDouble(2, phone);
			 preparedStatement.setString(3, email);
			 preparedStatement.setString(4, userName);
			 preparedStatement.setString(5, password);
			 
			 int i= preparedStatement.executeUpdate();
			 
			 if (i!=0)  //Just to ensure data has been inserted into the database
			 return "SUCCESS"; 
		 }
		 catch(SQLException e)
		 {
			e.printStackTrace();
		 }		 
		 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
	 }
}
