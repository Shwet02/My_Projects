package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Bean.Ticket;
import Util.TicketDBConnection;

public class TicketDao {
	public String bookTicket(Ticket tec)
	{
		String from=tec.getFrom();
		String to=tec.getTo();
		
		Connection con=null;
		PreparedStatement preparedStatement=null;
		try {
			con=TicketDBConnection.createConnection();
			String query="insert into TicketBooked(TicketFrom,TicketTo) values (?,?)";
			preparedStatement=con.prepareStatement(query);
			preparedStatement.setString(1,from);
			preparedStatement.setString(2,to);
			
			int i=preparedStatement.executeUpdate();
			
			if(i!=0) {
				return "SUCCESS";
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return "Oops...something went wrong!";
	}
}
